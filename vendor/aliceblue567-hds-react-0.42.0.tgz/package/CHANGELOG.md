# Changelog

`@aliceblue567/hds-react`의 버전별 변경 내용입니다. 버전 규칙은 [SemVer](https://semver.org/lang/ko/)를 따릅니다.
0.x 동안에는 마이너 버전(0.**1**.0 → 0.**2**.0)에서도 prop 이름이나 동작이 바뀔 수 있습니다. 바뀌면 여기에 **Breaking**으로 적습니다.

## 0.42.0 — 2026-10-22

대조 점검에서 나온 결정과 Figma에만 있던 동작을 코드에 넣었습니다.

- **Breaking** `Table` — `bordered` 기본값 true → false(Figma 기본값과 같음). 위쪽 1px 선이 필요한 표는 `bordered`를 넘겨야 합니다
- `AttachmentInput` — 선택 prop `onReorder(fromIndex, toIndex)`. 미리보기를 끌거나(터치는 0.3초 길게 누른 뒤) 키보드 화살표 · Home · End로 순서를 바꿈
- `BottomNavigation` — Hai 누름 모션(36 → 32), 탭 누름 표시(pill · Filled 아이콘)와 손 뗌 모션. 움직임 줄이기 설정에서는 끔
- `AttachmentItem` — 지우기 원에 1px stroke/neutral/default 선
- `Calendar` — 오늘 칸에도 Hover가 보이게 수정
- 문서: Select placeholder는 항상 「선택해주세요」(예시값 규칙 삭제)

## 0.41.0 — 2026-10-22

Figma 가이드에 있는데 스토리북에 빠져 있던 섹션 · 예시를 36개 문서에 채웠습니다(대조 점검 B).

- 새 컴포넌트 `ResponsiveOverlay` — 화면 폭 768 미만은 BottomSheet, 768 이상은 Dialog로 같은 내용을 띄움. 열린 채로 폭이 바뀌면 그 자리에서 전환
- `FooterMobile` · `FooterDesktop` — 본문 링크 색 fg/brand/primary → fg/informative/primary(2026-10-22 결정)
- 문서 공용 Anatomy: 한 부품에 핀 여러 개(`all`), 페이지 헤더에서 React 링크 숨김(`react: false`)
- 문서: Usage Do/Don't 추가(Attachment Input · Bottom Navigation · Calendar · Counter · Date Picker · Empty State · Pagination · Progress Circle · Ratings · Select · Skeleton · Slider · Tables), Contents · Behaviors · Spec · Dev Handoff · Accessibility 절 보강(Select · Date Picker · Empty State · Image Frame · List · Header · Footers · Toast & Snackbar · System Component 등)
- 문서: Tab/Chip 키보드 「화살표로 옮기면 바로 선택」으로 정리

## 0.40.0 — 2026-10-22

AI 코딩 도구(Claude Code · Cursor · v0)가 HDS를 읽을 수 있는 **AI Kit**을 패키지에 넣었습니다. 빌드 산출물이라 손으로 적는 값은 없습니다.

- `@aliceblue567/hds-react/ai/AGENTS.md` — 에이전트용 규칙(HDS 컴포넌트·토큰·아이콘만 사용, `data-hds="custom"` 마커, 상태·접근성·UX Writing) + 컴포넌트 인덱스. 바이브코딩 저장소 루트에 복사해 씁니다
- `@aliceblue567/hds-react/ai/hds-components.md` — 컴포넌트 104개의 props · 타입 · 기본값 · Figma 속성 대응 전체
- `@aliceblue567/hds-react/ai/hds-catalog.json` — 같은 내용의 기계용 카탈로그(토큰 · 아이콘 요약 포함)
- `@aliceblue567/hds-react/ai/hds-figma-map.json` — Figma 속성 → 코드 prop 대응표(Code Connect · 디자인→코드 변환용). JSDoc 첫머리의 ``Figma `속성명` `` 표기에서 읽습니다(230개 prop)
- `npm run ai-kit`(`scripts/build-ai-kit.mjs`) — `build:lib` 끝에 자동 실행

## 0.39.1 — 2026-10-22

Figma 가이드와 36개 문서를 나란히 놓고 대조한 결과 중 바로 고칠 것(A)을 모두 반영했습니다.

- `Accordion` — 보조 문구가 길 때 제목이 줄어들던 CSS 버그 수정. 제목은 줄지 않고 보조 문구가 먼저 1줄 말줄임
- `BottomSheet` — 동작 줄이기 설정에서 닫힐 때 페이드(150ms) 없이 바로 닫히던 버그 수정
- `Rating` — 후기 수 캡션 줄바꿈 금지
- 스토리 화면: 컴포넌트를 캔버스 정중앙(가로 · 세로)에 놓음
- 문서: 휴대폰 폭에서 표 · 보드 · Do/Don't가 페이지를 옆으로 밀지 않게 안쪽 스크롤로
- 문서: Anatomy 핀 위치(Attachment Input · Button · Calendar · Counter · Date Picker · Empty State · Image Frame · Label · List · Pagination · Select · Skeleton · Slider), 낡은 문구(Button Focus 링, Bottom Sheet 90dvh, Bottom Navigation 모션, Chips SemiBold, Slider Focused, Tabs 간격, Text Input 레이블 12px 등), 예시 정리(실제 아이콘, Footers 데스크톱 축소, Dialog SafeArea 인디케이터, Tooltip 링크 노드 갱신)
- 문서: Bottom Sheet 판별 기준을 「768 미만 Bottom Sheet, 768 이상 Dialog」로 통일

## 0.39.0 — 2026-10-21

남은 열린 정본 점검 항목을 정리했습니다(11 → 1). Avatar 가이드 사진만 2026-10-02 결정대로 남습니다.

- `ProgressCircle` — `tone="inverse"` 추가. 사진 · 영상 · 딤 위에서 트랙 stroke/on-media/subtle(흰색 40%) · 진행 fg/on-media/primary
- 토큰: `--hds-stroke-on-media-subtle` 추가(두 모드 static/white-alpha-40)
- 토큰: Dark에서 `stroke/neutral/bold` gray-500 → gray-600, `stroke/neutral/emphasis` gray-600 → gray-500. 두 모드 모두 medium < bold < emphasis < strong 순서가 됩니다. Light는 그대로
- `Header` — `type="sub-details"` · `background="transparent"`면 제목을 화면에서만 숨깁니다(스크린 리더용 h1은 남음)
- Figma 가이드 보강: Avatar Anatomy 마커 · Toast/Snackbar Accessibility · Selection 단독형 Variants · Dialog Do/Don't 예시 · Image Frame fill 모서리 · Chips 헤더 · Progress Circle Inverse
- Figma: Slider/Value Bubble 단일 컴포넌트(Type 축 제거, 키 유지)

## 0.38.1 — 2026-10-21

- 문서: 「과정과 수치」 페이지 추가(진행 단계 · 수치 · 일하는 방식). Introduction 규모를 2026-10-21 실측(변수 620 · 텍스트 스타일 52)으로

## 0.38.0 — 2026-10-21

열린 정본 점검 항목을 정리했습니다(79 → 11). 결정이 나 있던 21건은 해결로, 정본 글만 낡았던 8건은 정본을 고쳐 해결로, 나머지는 2026-10-21 유진 결정대로 Figma · 코드를 고쳤습니다.

- `Rating` — 빈 별 fg/neutral/disabled → stroke/neutral/emphasis(3.03:1)
- `Calendar` — 구간 띠 위 비활성 휴일 숫자도 fg/neutral/disabled-bg
- `AttachmentItem` — 재생 아이콘 안쪽 black 고정
- `FooterMobile` — 펼침 아이콘 fg/neutral/subtle
- `Header` — 간편홈 꺼짐 배경 atomic → fg/neutral/disabled-strong(같은 값)
- `BottomNavigation` — 숨김 · 노출 전환 duration/base · easing/standard
- 남은 열린 항목 11건: Figma 가이드 문구 보강 5 · Avatar 가이드 사진 교체 · Header Sub Details 제목 · Progress Circle Inverse · Slider 단일값 축 · Color Dark stroke 순서 · Chips 가이드 헤더

## 0.37.0 — 2026-10-21

System Component를 추가했습니다(Figma HDS-Components ✅ System Component 17382:40369 · Keyboard 가이드 21182:280). OS가 그리는 참조물이라 그림은 다시 그리지 않고 입력 타입만 다룹니다.

- `keyboardProps(kind, enterKey?)` — 입력 내용(text · email · tel · number · mixed · upper · password)에 맞는 type · inputMode · autoCapitalize · autoCorrect · enterKeyHint. 숫자 전용은 inputMode=numeric
- `KEYBOARD_HANDOFF` — iOS · Android 자판 이름과 keyboardType · inputType 대응표
- 문서: System Component(범위 · 자판 표 · 여행자 정보 예시 · 키보드가 올라온 뒤 · 개발 전달)
- Components Overview 카드 36개가 모두 스토리북 문서로 연결(21개 docId 추가)

## 0.36.0 — 2026-10-21

- **Breaking** `Calendar` — 폭 360 고정 → 놓인 폭을 채우고 최대 628(Figma 2026-10-19 요일 · 머리글 7등분). 360에서는 칸 48 그대로, 628에서는 86. 고정 폭이 필요하면 감싸는 쪽에서 폭을 준다
- 문서: Calendar 「폭」 절 · 스토리 「폭 360 · 628」

## 0.35.1 — 2026-10-19

- `OverlayBody` — `hasAction`(Figma `Has Action`) 추가. 아래에 ActionArea가 없으면 맨 아래 40(spacing-10, 2026-10-15 하단 여백 규칙). BottomSheet · Dialog는 primaryAction 유무로 자동
- `OverlayActionArea` — 액션이 없으면 Safe Area 칸도 그리지 않음(Body가 아래 40을 가짐). SafeAreaSpacer 높이는 spacing-5
- Dialog 최소 치수 「ActionArea 없음」 모바일 320×172 → 320×196

## 0.35.0 — 2026-10-19

Overlay Parts를 추가했습니다(Figma HDS-Components ✅ Overlay Parts 13639:33).

- `OverlayHeader` — handle(기본 켬, 노드도 받음) · showClose(기본 끔) · align leading · center · description · ids. Handle + Close, Center + Close는 개발 모드 경고
- `OverlayBody` — padding default(좌우 20 · 아래 16) · none, 유일한 스크롤 영역
- `OverlayActionArea` — primaryAction · secondaryAction(Dual Equal) · safeArea(20 또는 OS inset)
- `BottomSheetPanel` · `DialogPanel`이 위 부품으로 조립되도록 바꿈(공개 props 변화 없음)
- Description 줄 높이 body/md(130%) → body/md-long(160%)
- 닫기 버튼을 내용 폭 안으로(아이콘 끝이 가장자리에서 32, Figma 그대로)
- Dialog Safe Area를 안쪽 여백 대신 SafeAreaSpacer로
- 정본 점검: code-deviates 51 · code-follows-spec 77 · open 81 · resolved 375

## 0.34.0 — 2026-10-19

C 묶음에서 미뤄 둔 결정을 반영했습니다(Figma HDS-Components · HDS-Foundation 함께 수정).

- 토큰: 반복 모션 `--hds-duration-loop-base`(1200ms) · `--hds-duration-loop-slow`(1500ms) 추가. ProgressCircle 회전 · Skeleton · ImageFrame 쉬머가 사용
- `Rating` — `showScore` 추가. 별 오른쪽에 평균 숫자(label/md-strong, 화면 전용)
- `Slider` — `disabled` 추가(핸들 bg/neutral/subtle + stroke/neutral/disabled, 고른 구간 fg/neutral/disabled-strong). `SliderRange`도 옵션 · 입력 칸을 함께 막음
- **Breaking** `SliderRange` 모드 전환이 체크박스에서 Button/Text Small 밑줄 버튼으로 바뀜
- `Copy` — Text Icon이 화살표 대신 ic-copy 12(간격 4). Icon Only 색 fg/neutral/subtle
- `CarouselCounter` 배경 overlay/dark/default(60%)
- `FooterDesktop` 위 가로선 stroke/neutral/subtle
- `AttachmentItem` 딤 위 글자 · 아이콘 white
- Slider 「~」 fg/neutral/disabled-strong
- 문서: Tables 예시 Text Button을 Default + 밑줄로, Slider State · Motion loop 토큰 절 추가
- 정본 점검: code-deviates 51 · code-follows-spec 76 · open 78 · resolved 371

## 0.33.0 — 2026-10-16

Tables를 추가했습니다(Figma HDS-Components ✅ Tables (테이블) Table 6639:514 · Table/Head 8359:728 · Table/Cell 8371:743).

- `Table` — size small(48 · 13) · large(56 · 15), bordered(맨 위 선), caption(기본 숨김), columnWidths, 가로 넘치면 키보드 스크롤
- `TableHead` — content title · subtitle · input · order(aria-sort 세 상태, 제목 전체가 버튼), align, scope
- `TableCell` — 최소 높이 · 여러 줄 위 정렬, title + description(descriptionFirst), align, fit. 버튼 · 배지 · 체크박스는 HDS 컴포넌트를 children으로
- Direction(Header Row · Header Column · Matrix)은 마크업으로 표현
- 예시 `SortableList`
- 정본 점검: code-deviates 54 · code-follows-spec 76 · open 98 · resolved 346

## 0.32.0 — 2026-10-16

Copy를 추가했습니다(Figma HDS-Components ✅ Copy (복사) 12838:16523).

- `Copy` — type icon-only · text-line · text-icon, 이름 「{target} 복사」, 결과를 `aria-live`로 알림, 누르는 영역 사방 8 넓힘
- `copyText` — clipboard API, 막힌 곳에서는 execCommand로 물러남
- 예시 `ReservationNumber`: 복사 결과를 Toast로
- 정본 점검: code-deviates 53 · code-follows-spec 74 · open 95 · resolved 346

## 0.31.0 — 2026-10-16

Footers를 추가했습니다(Figma HDS-Components ✅ Footers (푸터) Footer/Mobile 4469:896 · Footer/Desktop 4775:559).

- `FooterMobile` — 맨 위 3칸 · 약관 링크 · 사업자 정보(펼침, `aria-expanded`) · ※ 고지 · 저작권. Expand는 expanded · defaultExpanded
- `FooterDesktop` — 공지 한 줄 · SNS(누르는 영역 44) · 약관 · 사업자 정보 줄 · 연락처(tel:) · 고지 · 저작권 · 오른쪽 칸 · 아래 띠(수상 마크 넘겨 보기 · 인증 마크). 콘텐츠 폭 1200(layout/content-width-lg의 Desktop 값)
- `FooterInlineLink` — 본문 안 브랜드 색 밑줄 링크
- 문구는 모두 props. 문서 예시는 Figma 실물 문구에서 사람 이름을 가렸고, 상표(SNS 로고 · 수상 마크)는 빈 자리로 둠
- 정본 점검: code-deviates 52 · code-follows-spec 74 · open 90 · resolved 346

## 0.30.0 — 2026-10-16

Empty State를 추가했습니다(Figma HDS-Components ✅ Empty State (엠프티 스테이트) 16480:91).

- `EmptyState` — type empty · no-result · error(정본 기본 문구), size default(아이콘 64 · 위아래 80) · compact(48 · 32), Show Icon · Heading · Description · Button
- `placement` — content는 가운데에서 위로 3.5% · 위 여백 최소 80 · 최대 영역의 25%, section은 그냥 가운데. 부모 영역 높이를 재서 계산하고 영역이 모자라면 늘어나 스크롤
- Type=Error는 `role="alert"`
- 예시 `SavedPlaces`
- 정본 점검: code-deviates 50 · code-follows-spec 73 · open 84 · resolved 346

## 0.29.0 — 2026-10-16

Pagination을 추가했습니다(Figma HDS-Components ✅ Pagination (페이지네이션) Directional 9886:296 · Carousel Indicator/Dot 9886:310 · Carousel Indicator/Overlay 9886:318).

- `Pagination` — Directional. type standard(끝에서 화살표 disabled) · infinite(끝에서 처음으로), indicator count · dot. 버튼 56 × 32(누르는 영역 44), `nav` · `aria-live`
- `CarouselDots` — Carousel Indicator/Dot. 점 6 · 사이 4, color default · white, 개수는 total만큼
- `CarouselCounter` — Carousel Indicator/Overlay. type number · media · more(onMore를 주면 전체보기 버튼)
- 예시 `PhotoCarousel`
- 정본 점검: code-deviates 49 · code-follows-spec 72 · open 79 · resolved 346

## 0.28.0 — 2026-10-16

Ratings를 추가했습니다(Figma HDS-Components ✅ Ratings (별점) Rating/Star 8048:1071 · Rating 9192:1101 · Rating/Helpful Button 8053:2046).

- `Rating` — Size=Small 보여 주기. 별 16 다섯 개 + 「N명의 여행후기」, 평균은 0.5 단위 내림, `role="img"` 「5점 만점에 N점」
- `RatingInput` — Size=Large 매기기. 별 40(누르는 영역 44), `radiogroup`, 점수 문구 「별을 선택해주세요 · 별로였어요 … 최고였어요」
- `HelpfulButton` — Type button(aria-pressed, 누르는 영역 44) · text
- `RatingStar` — 부품. Fill full · half · empty × Size 12 · 16 · 40
- Skeleton 문서의 정본 대조를 skeleton.md v1.1 기준으로 고침
- 예시 `ReviewCard`
- 정본 점검: code-deviates 48 · code-follows-spec 70 · open 74 · resolved 346

## 0.27.0 — 2026-10-16

Skeleton을 추가했습니다(Figma HDS-Components ✅ Skeleton (스켈레톤) Rectangle 12753:5798 · Circle 10415:450 · Text 12753:5902).

- `SkeletonRectangle`(모서리 8) · `SkeletonCircle` · `SkeletonText`(한 줄 32, Length 100 · 75 · 50 · 25, Align leading · center · trailing), Color normal · white
- `SkeletonGroup` — `role="status"` · `aria-busy`, 숨긴 문구로 로딩을 한 번 알림
- 쉬머 좌 → 우 1500ms ease-in-out. 늦게 그려진 Skeleton도 화면의 다른 Skeleton과 박자를 맞춤
- White는 고정 흰색 20%(Figma의 fg/neutral/contrast는 다크에서 어두워짐)
- `ImageFrame` 로딩 쉬머를 1.2s · easing/standard에서 1500ms ease-in-out으로 맞춤
- 예시 `ProductListLoading`
- 정본 점검: code-deviates 47 · code-follows-spec 68 · open 67 · resolved 346

## 0.26.0 — 2026-10-16

Progress Circle을 추가했습니다(Figma HDS-Components ✅ Progress Circle (프로그레스 서클) 16311:2541).

- `ProgressCircle` — Size small(24 · 두께 3) · medium(32 · 4, 기본) · large(40 · 5), Tone neutral · brand. 스트로크 링 + 둥근 끝 호
- `value`(0~100)를 주면 Determinate(300ms로 채움), 없으면 Indeterminate(1200ms 회전 + 앞머리 · 꼬리 이징을 따로 줘 호 길이가 변함)
- 움직임 줄이기에서는 25% 호가 3초에 한 바퀴 등속으로 돎
- `AttachmentItem` loading이 임시 고리 대신 ProgressCircle Medium · Neutral을 씀
- 예시 `UploadProgress`: 연결 중 Indeterminate → 진행률 Determinate
- 정본 점검: code-deviates 46 · code-follows-spec 66 · open 63 · resolved 346

## 0.25.0 — 2026-10-16

Attachment Input을 추가했습니다(Figma HDS-Components ✅ Attachment Input (첨부 입력) 11367:3409).

- `AttachmentInput` — Trigger 옆에 Item을 가로로 나열(행 높이 84 · 아래 정렬), `dropzone`을 켜면 PC용 Dropzone을 위에 둠. 최대 개수에 닿으면 Trigger Disabled, 남은 자리만큼만 onAdd로 넘김
- `AttachmentTrigger` — 80 × 80, 첨부 전 「첨부하기」 · 첨부 후 「n/max」
- `AttachmentItem` — Type image · video × State default · loading · error · disabled, 대표사진 띠(`badge`), 지우기 24(누르는 영역 44), error에서 「재시도」
- `AttachmentDropzone` — 점선 1.5(6 · 4), 끌어 놓기 · 눌러서 고르기, Drag Over
- 예시 `ReviewPhotos`: 첫 장 대표, 올리기 · 실패 · 재시도 흉내
- 정본 점검: code-deviates 47 · code-follows-spec 64 · open 58 · resolved 345

## 0.24.0 — 2026-10-16

Slider를 추가했습니다(Figma HDS-Components ✅ Slider · Slider/Range 3983:238 · Slider/Track 9340:1392 · Slider/Value Bubble 9240:2054).

- `Slider` — 범위(핸들 두 개). 트랙은 놓인 폭을 채우고 핸들 20, 누르는 영역 44. 말풍선은 고른 구간 가운데 위에 두되 트랙 안으로 맞춤. `format`으로 말풍선 · 스크린리더 값 글자를 정함. `onChangeEnd`는 손을 떼거나 키를 놓을 때 한 번
- `SliderRange` — `type` slider · input. 오른쪽 위 옵션 체크(「직접입력」 · 「그래프로 입력」)로 바꿈. input은 Text Input 두 칸, 벗어날 때 범위 안으로 맞추고 순서를 바로잡음
- 키보드: 화살표 한 칸 · PageUp · PageDown 10분의 1 · Home · End
- Figma에 Disabled · Focused 변형이 없어 포커스 링만 포커스 표시 기준대로 그렸습니다
- 정본 점검: code-deviates 46 · code-follows-spec 62 · open 53 · resolved 345

## 0.23.0 — 2026-10-16

Counter를 추가했습니다(Figma HDS-Components ✅ Counter (수량 조절) 4290:653).

- `Counter` — Counter/Minus + Counter/Number + Counter/Plus. `min` · `max`에 닿으면 그쪽 버튼이 Disabled, `disabled`면 수량 칸까지 Disabled. 누르면 테두리만 stroke/neutral/bold(duration/instant). 길게 누르면 500ms 뒤 100ms마다 1씩(`holdToRepeat`, 기본 켬). 보이는 32, 누르는 영역 44
- `CounterItem` — `layout` inline · stacked, `price` · `description` · `tooltip`(물음표를 누르면 Tooltip)
- `TriggerIcon`에 `size` 16 추가(작은 글자 옆). 누르는 영역은 28 그대로
- 예시 `Travelers`: 성인 · 아동 · 유아, 한 예약 9명 · 유아는 성인 수까지
- 정본 점검: code-deviates 45 · code-follows-spec 61 · open 47 · resolved 345

## 0.22.0 — 2026-10-16

Date Picker를 추가했습니다(Figma HDS-Components ✅ Date Picker 20016:2).

- `DatePicker` — `layout` inline · popover · sheet, `selection` single · range, 머리글 연 · 월을 눌러 연 · 월 휠로 건너뛰기(`showMonthYear`). `min` · `max`가 속한 달 밖으로는 이전 · 다음 버튼이 Disabled. `onComplete`는 single은 날짜를, range는 종료일을 누를 때 불려 Popover를 닫는 데 씁니다
- `DatePickerTwoMonths` — PC 기간 선택. 두 달 나란히 720 고정
- `DatePickerSheet` — 바텀시트에 담고 「날짜 선택 완료」로 확정. 확정 전까지 바깥 값을 바꾸지 않고, range는 종료일까지 골라야 버튼이 눌립니다
- 부품 `DatePickerHeader` · `DatePickerNavButton`(Hover skeleton/base · Pressed skeleton/strong) · `DatePickerWeekdays` · `MonthYearPicker`(spinbutton 두 칸)
- 키보드: 화살표 · Home · End에 PageUp · PageDown(한 달, Shift 한 해). 포커스가 달 끝을 넘어가면 보이는 달도 넘어갑니다
- `CalendarDay`에 `fluid` 추가(칸이 놓인 폭을 채움). 원 위치와 구간 띠 시작 · 끝을 칸 폭 비율로 바꿨습니다 — 48 칸에서는 이전과 같습니다
- 예시 `DateField`: Select `type="date"` + PC Popover / 모바일 Sheet
- 정본 점검: code-deviates 45 · code-follows-spec 58 · open 42 · resolved 344

## 0.21.2 — 2026-10-15

Foundation › Typography에 「본문 최소 크기 12」 규칙을 추가하고, 규칙에 어긋난 컴포넌트 글자를 올렸습니다(Figma HDS-Foundation Typography 「보강 · 본문 최소 크기 12」 14023:26).

- 본문 글자는 `label/md`(Mobile 12) 아래로 쓰지 않습니다. 보조 · 메타 정보 · 각주 · 안내문 · 입력창 라벨 · 도움말 · 금액 하위 항목, 컴포넌트 안 보조 문구 · 날짜 아래 표기도 본문입니다
- `caption/*`(8 ~ 11)는 라벨 칩(Label · Badge · Common/Label · Package/Label)과 외부 브랜드 · 인증 마크 안 글자에만 씁니다. 접근성 표의 「caption md · lg는 저작권 · 타임스탬프 같은 보조 표기 전용」(2026-10-01)을 바꿨습니다
- 역할별 사용 표: 「캡션·주석 = Caption」 행을 「각주·안내·도움말 = Label Medium」과 「라벨 칩·브랜드 마크 = Caption」으로 나눴습니다. Do / Don't 예시 `MinSizeSample`
- **글자 크기 변경(시각 변경)** — 아래를 `caption/*` → `label/md`(weight 유지)로 올렸습니다
  - `TextInput` 도움말(`.hds-field__desc`) 11 → 12, 떠오른 안쪽 레이블 10 → 12
  - `Select` 도움말(`.hds-select__desc`) 11 → 12
  - `CheckboxItem` `size="xsmall"` 도움말 caption/lg → label/md
  - `BottomFixed` 날짜 구간 레이블(`.hds-bottompanel-range__label`) 11 → 12
  - `CalendarDay` 날짜 아래 라벨(`.hds-cal-day__label`) caption/lg-strong → label/md-strong
- 그대로 둔 것(예외): `Label` · `Badge`(Number · Label Badge) · `TooltipBadge` · `ImageFrame` 이미지 라벨 — 라벨 칩
- 그대로 둔 것(판단 필요 — Figma 원본 정리 결과에 맞춤): `Button` small(11) · xsmall(10) 버튼 글자, `BottomNavigation` 탭 라벨(10), `Header` 아이콘 캡션(8) · 탭 보조 문구(10)
- 문서 본문 글자(Divider · Button 문서 패널, Spacing 모서리 용도, Typography 줄 길이 설명, CitySearch 예시)도 12로 올렸습니다
- 정본 점검: code-deviates 42 · code-follows-spec 57 · open 37 · resolved 344

## 0.21.1 — 2026-10-15

Foundation › Spacing & Radius 문서에 「화면 하단 여백」 규칙을 추가했습니다(Figma HDS-Foundation Grids & Layouts › Grid & Spacing 가이드 「보강 · 화면 하단 여백」 14013:2084). 코드 변경은 없습니다.

- Bottom Fixed가 없는 화면과 팝업(전체 화면 오버레이 포함)은 스크롤 콘텐츠 맨 아래에 `spacing/10`(40)을 둡니다. 마지막 요소가 홈 인디케이터 · 화면 끝에 붙지 않게 하는 여백입니다
- Bottom Fixed가 있는 화면은 이 여백을 따로 두지 않습니다(Bottom Fixed가 아래 여백을 이미 가짐)
- 44처럼 간격 토큰에 없는 값은 쓰지 않습니다. 패키지 화면 재구성의 하단 여백 44(12곳)를 40으로 통일했습니다
- 예시 보드 `BottomSafeSpace`(Bottom Fixed 없음 · 있음)
- 정본 점검: code-deviates 42 · code-follows-spec 57 · open 37 · resolved 343

## 0.21.0 — 2026-10-15

Calendar를 추가했습니다(Figma Calendar 822:878 · Calendar/Day 2646:2744).

- 새 컴포넌트 `Calendar`: 한 달 달력. `month`, `mode`(single · range), `value` · `onChange`, `days`(날짜별 라벨 · 공휴일 · 비활성), `today`, `min` · `max`, `size`(default · small), `showMonthTitle`, `monthSelect`(「월 전체」 Checkbox Item)
- 새 컴포넌트 `CalendarDay`: 날짜 한 칸 48 × 49. Figma 49 State를 `selection`(none · single · start · end · in-range · middle) · `holiday` · `today` · `label` · `tone`(price · lowest · mid · highest · info · marker · today) · `disabled` 조합으로 그립니다
- 실측: 원 28, 구간 띠 높이 28(시작 · 끝 25), 숫자 body/sm-emphasized(위 4.5), 라벨 caption/lg-strong(위 32.5), 연월 32 · 24, 요일 36 · 14, 좌우 12
- 구간 띠 위 비활성 평일은 `fg-neutral-disabled-bg`(2026-10-08 규칙)
- 접근성: grid · gridcell, roving tabindex, 화살표 · Home · End, `aria-current="date"`, 포커스 링 focus/default
- 없는 것: Calendar/Week, 다구간 선택
- 정본 점검: code-deviates 42 · code-follows-spec 56 · open 37 · resolved 342
## 0.20.1 — 2026-10-15

Foundation › Iconography 문서에 아이콘 규칙 두 가지를 추가했습니다(Figma HDS-Foundation Iconography 가이드 11957:5091의 Icon & Text Pairing 13984:81 · Aspect Ratio 13984:123). 코드 변경은 없습니다.

- Icon & Text Pairing: 텍스트 바로 옆 인라인 아이콘은 옆 텍스트 크기로 토큰을 정합니다. 13 이하 icon-3(12) · 14–15 icon-4(16) · 16–17 icon-5(20) · 18 이상 icon-6(24), 세로 가운데 정렬. 세로 배치 기능 아이콘 · 별점 · 버튼 안 아이콘과 HDS 컴포넌트 안 아이콘은 제외
- Aspect Ratio: 정사각형이 아닌 아이콘은 높이만 토큰으로 정하고 너비는 원본 비율을 따릅니다(chevron Tight 28 × 48 → icon-4에서 9.33 × 16). 정사각형 틀에 맞추지 않습니다
- `Icon`은 이미 `size`를 높이로 받고 너비를 원본 비율로 계산합니다. Props 표 설명에 「width를 따로 넘기지 않는다」를 보탰습니다
- 정본 점검: code-deviates 39 · code-follows-spec 54 · open 32 · resolved 338

## 0.20.0 — 2026-10-15

Select를 추가했습니다(Figma Select 9991:1569 · Select/Default 1908:800 · Select/Menu 13311:1294).

- 새 컴포넌트 `Select`: `type`(default · date · time · search), `size`(40 · 48), `status`(normal · negative, default만), `description`, `disabled`, `showLabel`, `leadingIcon`(default만)
- type=default에 `options`를 넘기면 필드 아래 Select/Menu(List Cell 행, 최대 높이 320, 결과 없음 문구)가 열립니다. 키보드 ↓ · Enter · Space 열기, ↑↓ 옮기기, Enter 고르기, Esc 닫기. date · time · search는 `onOpen`으로 앱이 고르는 화면을 열고 `displayValue`로 값을 받습니다
- 실측: 필드 48 · 40, 모서리 8 · 6(Large 6은 2026-10-15 결정으로 유지), 값 글자 15 · 14, 앞 아이콘 Default 24 · 20 · 그 밖 20, 레이블 간격 8, 도움말 간격 4, Menu 행 53
- 비활성 색은 2026-10-08 규칙(면 안 글자 · 아이콘 `fg-neutral-disabled-bg`, 도움말 `fg-neutral-disabled`)
- `ListCell`에 `id` prop 추가(aria-activedescendant용)
- 없는 것: 다중 선택(Chip · 확인 버튼). 앱의 Bottom Sheet 목록은 `onOpen`으로 엽니다
- 정본 점검: code-deviates 39 · code-follows-spec 54 · open 32 · resolved 338

## 0.19.0 — 2026-10-14

Banner를 추가했습니다(Figma Banner 10586:26987).

- 새 컴포넌트 `Banner`: 글자 · 그림이 담긴 통이미지 한 장 + 선택 페이지 표시. `level`(1 · 2 · 3 · 3-wide · 4 · 5 · 6-wide)이 비율을 정하고(320 × 48 ~ 360 × 180), `pagination`(dot · overlay)을 받습니다. `alt` 필수, `href`면 링크 · `onClick`만 있으면 버튼
- Figma 가이드의 개발 참고사항대로 크기와 페이지 표시만 제어합니다. 글자 · 버튼 prop은 없습니다
- 모서리 Level 1 · 2는 8, Level 3 · 4 · 5는 12, Wide는 0. Overlay는 Level 1 · 2에서 오른쪽 8 · 세로 가운데, 그 이상은 오른쪽 12 · 아래 12
- 정본 점검: code-deviates 37 · code-follows-spec 53 · open 30 · resolved 334

## 0.18.0 — 2026-10-14

Header를 추가했습니다(Figma Header/GNB 2202:1639).

- 새 컴포넌트 `Header`: `type` 여섯 가지(main · main-simple · sub · sub-details · popup · search), `background`(white · transparent, transparent는 sub · sub-details · popup만), `showGradient`, `actions`(우측 아이콘 최대 3, 8 글자 · Dot · Count 배지), main의 검색 진입 버튼 · 탭 줄, main-simple의 간편홈 전환, search의 Search Field
- 실측: 줄 52, Main 검색 진입 205×36, 우측 묶음 64 · 104 · 68×33 · 96 · 60, Search 입력칸 256×40으로 Figma와 같습니다
- 탭 줄 아래 구분선은 `stroke-neutral-subtle`(Figma도 2026-10-14 `fg/brand/disabled`에서 바꿈)
- 없는 것: 상태 표시줄(OS 몫), 제목 옆 Dropdown · Info, Trailing Group Toggle, Header/Mobile · Header/Desktop
- 정본 점검: code-deviates 36 · code-follows-spec 50 · open 29 · resolved 328

## 0.17.0 — 2026-10-14

Bottom Navigation을 추가했습니다(Figma 10260:37037).

- 새 컴포넌트 `BottomNavigation`: 목적지 4개 + Hai 버튼 다섯 칸. `platform`(ios · android · web)으로 바닥 여백 20 · 8 · 12, `scrollState="scrolled"`이면 Top과 Hai만 오른쪽에 뜹니다. 지금 화면 탭은 `aria-current="page"`를 받습니다
- 표면은 `bg-layer-floating`(Light 흰색 α0.90 · Dark 불투명). Figma 표면 칠 불투명도 90%가 토큰 위에 겹쳐 있던 것을 100%로 고친 뒤 기준입니다(2026-10-14 결정)
- Tablet 폭(표면 440)은 `<html data-platform="tablet">`을 따릅니다
- 없는 것: Hanaon · Hanalive · 말풍선, 표면 Glass 효과(Figma는 리뉴얼 전까지 유지), 숨김 · 노출 모션
- 정본 점검: code-deviates 33 · code-follows-spec 48 · open 26 · resolved 325

## 0.16.0 — 2026-10-12

소수 간격 토큰의 표기를 `_` 하나로 통일했습니다(개발 요청). 값은 그대로입니다.

- 이름 변경: `spacing-05` → `spacing-0_5`, `spacing-negative-05` → `spacing-negative-0_5`. `spacing-1_5`와 같은 표기이고, Ratio의 `1_618`과도 같습니다. Figma 변수 이름과 Web code syntax를 함께 바꿨습니다
- 옛 CSS 이름 `--hds-spacing-05` · `--hds-spacing-negative-05`는 0.16.x 동안 새 이름을 가리키는 별칭으로 남깁니다. 다음 마이너에서 지웁니다
- **Breaking(네이티브)**: Swift · Compose `spacing05` → `spacing0_5` · `spacingNegative05` → `spacingNegative0_5`, Android `hds_spacing_05` → `hds_spacing_0_5`. 네이티브에는 별칭이 없습니다
- 사용처 13개 파일을 새 이름으로 옮겼습니다
- 정본 점검: code-deviates 29 · code-follows-spec 47 · open 24 · resolved 323

## 0.15.2 — 2026-10-12

입력 필드의 포커스 표시를 Focused 테두리 하나로 정리했습니다.

- `SearchField` · `TextInput`: 필드 바깥 2px 포커스 링을 뺐습니다. 글자 입력칸은 마우스로 눌러도 브라우저가 `:focus-visible`로 취급해 Focused 테두리와 선이 항상 두 줄이 됐습니다(2026-10-12 결정). 필드 안 지우기 · 뒤로 · 닫기 · 물음표 버튼은 2px 링을 유지합니다
- 정본 점검: code-deviates 29 · code-follows-spec 47 · open 24 · resolved 322

## 0.15.1 — 2026-10-12

Dark 플레이스홀더 대비와 비활성 글자 색을 Figma에 맞췄습니다.

- 토큰: `fg/neutral/placeholder` Dark gray-500(#aaaaaa) → gray-400(#bbbbbb). `bg/neutral/muted` 위 4.19 → 5.07(Search Hovered). Dark에서 `disabled-strong`과 같던 값도 갈라졌습니다. Light는 그대로입니다(2026-10-12 결정)
- `TextInput` Disabled: 필드 안 값 · 플레이스홀더 · 안쪽 레이블은 `fg/neutral/disabled-bg`, 바깥 레이블 · 도움말은 `fg/neutral/disabled`. Size 40 바깥 레이블도 이제 흐려집니다(2026-10-08 비활성 전경 규칙)
- `FilterChip` · `SelectChip` · `ChoiceChip` · `ChipTabs` Disabled 글자 · 아이콘 `fg/neutral/disabled` → `disabled-bg`(같은 규칙)
- 정본 점검: code-deviates 29 · code-follows-spec 48 · open 24 · resolved 320

## 0.15.0 — 2026-10-12

Figma HDS-Foundation의 2026-10-08 토큰 이름 정리를 따라갔습니다. 색 값은 바뀌지 않았습니다.

- 이름 변경: `bg/surface/primary` → `bg/layer/basement`, `bg/neutral/primary` → `bg/layer/default`, `bg/neutral/floating` → `bg/layer/floating`, `bg/brand/subtle` → `bg/brand/muted`, `bg/brand/disabled` → `bg/brand/subtle`. 컴포넌트 · 문서의 사용처를 전부 새 이름으로 옮겼습니다
- 옛 CSS 이름 4개(`--hds-bg-surface-primary` · `--hds-bg-neutral-primary` · `--hds-bg-neutral-floating` · `--hds-bg-brand-disabled`)는 한 마이너 버전 동안 새 이름을 가리키는 별칭으로 남깁니다
- **Breaking**: `--hds-bg-brand-subtle`은 이름이 재사용돼 값이 바뀝니다(brandpurple-100 → 50). 옛 값을 쓰던 곳은 `--hds-bg-brand-muted`로 옮기세요. 네이티브 토큰(Swift · Compose · XML)은 별칭 없이 새 이름만 있습니다
- 새 토큰: `fg/on-media/primary`(사진 · 영상 · 딤 위 글자와 아이콘, 두 모드 흰색)
- 문서: Color에 `bg/layer` 세 단계, 어두운 면 세 가지, 고정색 규칙(`semantic/white · black`은 컴포넌트 내부 전용)을 적었습니다

## 0.14.0 — 2026-10-12

Search를 새로 추가했습니다(stage 3 묶음 A).

- `SearchField`: Figma Search Field(16228:3324). 높이 40 · 회색 면(bg/neutral/subtle) · Hovered bg/neutral/muted · Focused 1px stroke/neutral/strong. `showSearchIcon`(기본 true, GNB에서만 끔), `onClear`, `onSearch`(Enter). 지우기는 값이 있고 비활성이 아닐 때만 나오며 prop이 없습니다
- `SearchBar`: Figma Search Bar(16228:38712). 높이 56 · `showBack` · `showClose`(함께 켜면 개발 중 경고) · `role="search"`
- Figma Search Field Disabled의 돋보기를 fg/neutral/disabled-bg로 맞췄습니다(2026-10-12 결정). 가이드 Spec 표의 Disabled 토큰과 Select/Search 이름도 고쳤습니다
- 정본 점검: code-deviates 29 · code-follows-spec 49 · open 26 · resolved 311

## 0.13.0 — 2026-10-12

Image Frame과 Image Label을 새로 추가했습니다(stage 3 묶음 A).

- `ImageFrame`: Figma Image Frame(8458:1772) · Image Frame/Square(8458:559). `ratio` 13종 + `original`, `size`(Square 13단, 모서리는 크기 단계), 없으면 부모 폭을 채움(fill). `rounded`(16) · `border`(overlay/adaptive/tint) · `loading`(skeleton shimmer). `src`가 없거나 실패하면 Fallback(bg/neutral/strong + 하나투어 심볼 1/3, 32보다 작은 크기는 심볼 숨김)
- `ImageLabelGroup`: Figma Common/Image Label · Image Label Group. brand · blue · orange, 두 개까지(두 번째는 8 겹침), 9글자
- `ListThumbnail`이 `ImageFrame size={56}`을 씁니다. src가 없을 때 회색 자리 대신 Fallback 심볼이 보입니다
- Foundation Ratio 설명에 「코드 구현 13종」을 넣었습니다(2026-10-12 결정, T0)
- 정본 점검: code-deviates 29 · code-follows-spec 45 · open 24 · resolved 307

## 0.12.0 — 2026-10-12

0.11.0에서 바꾼 Label 세 가지를 기존 결정대로 되돌렸습니다. Figma도 같이 되돌렸습니다.

- **Breaking** `Label` `variant="outlined-subtle"` → `"tinted-outlined"`(0.10.0과 같음). 2026-10-07 이름 체계에서 확정한 값입니다
- Filled Mint 면: `fg/accent-mint/primary`로 복귀. fg 변수는 면에 써도 범위 위반이 아니고(2026-10-06), `bg/accent-mint/default`는 본문 크기 라벨에 쓰지 않기로 한 배경입니다(2026-09-30)
- Outlined Black 테두리: `fg/neutral/muted`로 복귀. 값이 같은 stroke 토큰이 없으면 그대로 둔다는 선례(2026-10-02)를 따릅니다
- 레이아웃 정리(상하 패딩 0 · 테두리 안쪽 · Tinted Medium Pink 좌우 6)는 그대로입니다
- 정본 점검: code-follows-spec 43 · open 21 · resolved 302

## 0.11.0 — 2026-10-12

Figma Common/Label을 기준에 맞게 고친 것을 따라갑니다.

- **Breaking** `Label` `variant="tinted-outlined"` → `"outlined-subtle"`. Figma 축 값 `Tinted Outlined`를 `Outlined Subtle`로 바꿨습니다(채움 없이 연한 테두리만 있어 이름과 생김새가 달랐음)
- Filled Mint 면: `fg/accent-mint/primary` → `bg/accent-mint/default`(다른 Filled와 같은 규칙, Light가 조금 밝아짐)
- Outlined Black 테두리: `fg/neutral/muted` → `stroke/neutral/strong`(Light #444 → #111)
- 정본 점검: open 20 · figma-fix 0 · resolved 305

## 0.10.0 — 2026-10-12

Label을 새로 추가했습니다(stage 3 묶음 A).

- `Label`: Figma Common/Label(4528:549). `variant`(outlined · tinted · filled · tinted-outlined) × `color`(purple · blue · mint · pink · red · gray · black) × `size`(small 16 · medium 20), `leadingIcon` · `trailingIcon`(12). Figma에 없는 조합(Gray × outlined · filled, Black × tinted · tinted-outlined)은 타입에서 막습니다
- 2026-10-12 결정: 표준 높이는 16 · 20. 각진 Label은 속성, 알약 `LabelBadge`는 강조 · 프로모션. Filled Blue · Pink · Mint 흰 글자는 유지하고 대비 미달을 결함으로 기록
- List: Trailing Label 예시를 `LabelBadge`에서 `Label`(Tinted · Gray)로 바꿨습니다
- 정본 점검: code-deviates 27 · code-follows-spec 41 · figma-fix 2 · open 23 · resolved 300

## 0.9.0 — 2026-10-08

Foundation을 10-06 ~ 10-08 결정(리뉴얼 반응형 · 글자 규칙)과 발행된 HDS-Foundation에 맞췄습니다.

- 토큰: Figma를 다시 내보냈습니다. `typography-scale` iOS 모드(size = Mobile + 1), `layout/content-max-width`(Mobile 628 · Tablet 720 · Desktop 1200), 그리드 스타일 이름(`grid/mobile-360` · `grid/tablet-768` · `grid/desktop-1280`, Desktop 마진 40)이 들어왔습니다. 색 · 그림자 · 그라디언트는 바뀌지 않았습니다
- CSS: `<html data-os="ios">`이면 글자 크기만 iOS 모드가 되고 창 폭과 관계없이 유지됩니다(R13 · R16). `[data-platform="tablet"]`이 Tablet 모드 글자 값을 직접 씁니다(지금은 Mobile과 같음)
- **`.hds-container` 최대 폭이 바뀝니다**: `content-width-lg` 대신 `content-max-width` + 양쪽 마진. Mobile에서 콘텐츠가 360에서 멈추던 것이 628까지 늘어납니다(Tablet 768 · Desktop 1280은 그대로)
- `base.css`: `text-size-adjust: 100%` — 글자가 시스템 · 브라우저 설정으로 커지지 않습니다(R12)
- `breakpoints`에 `renewal`(768 · 1280)을 더했습니다. `platformForWidth()`의 기본 기준이 `'web'`에서 `'renewal'`로 바뀌었습니다 — 값이 같아 결과는 같습니다. `app`(628)은 현행 앱뷰용으로 남습니다
- 네이티브: iOS 글자를 iOS 모드 값에서 만듭니다. `.hdsText()`는 `Font.custom(_:fixedSize:)`로 다이내믹 타입을 따르지 않고, Compose `HdsTheme`은 `fontScale`을 1로 고정합니다(R12)
- 스토리북: 툴바에 OS(Web · Android / iOS 앱)를 더했습니다. Typography의 Type Usage 표가 4모드를 보여 주고, 반응형 절을 리뉴얼 규칙(폭으로 키우지 않음 · iOS +1 · 시스템 글자 크기 고정)으로 고쳐 썼습니다. Grid & Layout은 현행과 리뉴얼 브레이크포인트를 나눠 적고, iOS 「375pt 변환 · 1:1.04」를 지웠습니다

## 0.8.0 — 2026-10-08

List를 새로 추가했습니다(stage 3 묶음 A).

- `ListCell`: Figma List Cell(10843:954). `title` · `subtitle` · `leading` · `trailing` 슬롯, `chevron` · `divider` · `density`(compact · standard · spacious) · `verticalAlign` · `selected` · `disabled`. `href`면 a, `onClick`이면 button, `as="label"`이면 행 전체가 Checkbox · Radio · ToggleSwitch의 라벨이 됩니다
- `List`: ul/li로 감싸고 마지막 행의 구분선을 지웁니다
- 부품: `ListValue` · `ListCheck` · `ListLargeIcon` · `ListThumbnail`
- 상태: Hovered skeleton/base 6% · Pressed skeleton/strong 8% · Selected bg/neutral/subtle(반응 없음) · Disabled는 글자 · 아이콘 · 셰브런 모두 fg/neutral/disabled-bg(2026-10-08 결정)
- 정본 점검: code-deviates 28 · code-follows-spec 39 · open 18 · resolved 290

## 0.7.7 — 2026-10-08

- `TriggerIcon`: `kind` 기본값을 `question`에서 `info`로 바꿨습니다. Figma `Tooltip/Trigger Icon` 세트의 기본값이 Info가 됐습니다(옛 `Type=Old`를 Info로 옮기고 보관). `kind`를 적지 않은 곳은 물음표 대신 i 아이콘이 나옵니다
- 정본 점검: Trigger Icon Old를 resolved로. code-deviates 25 · code-follows-spec 38 · open 17 · resolved 280

## 0.7.6 — 2026-10-08

Tooltip & Popover 정본 점검에 남아 있던 Figma 수정 항목을 처리했습니다. 코드 동작은 바뀌지 않았습니다.

- Figma Tooltip/Badge: 닫기 아이콘을 글자와 같은 토큰으로(Filled `fg/neutral/contrast`, Outlined `fg/brand/primary`), 안쪽을 오토 레이아웃으로 정리했습니다. 꼬리 중심이 알약 끝에서 18로 코드와 같아졌습니다
- Figma 가이드: Popover 헤더, Tooltip Usage 중복 줄과 보드 제목, Popover Position의 옛 라벨, Outlined 꼬리 안쪽 토큰을 고쳤고 Popover 가이드에 Behaviors · Accessibility 절을 넣었습니다
- 정본 점검: Tooltip/Trigger Icon Info는 고칠 것이 없음으로 정정, Type=Old는 8곳에서 쓰여 figma-fix로 남김
- 정본 점검: code-deviates 25 · code-follows-spec 38 · figma-fix 1 · open 17 · resolved 279

## 0.7.5 — 2026-10-08

Key Value 이름 표현을 결정 ⑨에 맞췄습니다.

- `PopoverKeyValue`: 이름 색을 `fg/brand/primary` Regular에서 `fg/neutral/primary` + `label/md` emphasized(600)로 바꿨습니다. 강조는 색이 아니라 굵기로 합니다(2026-09-14 색 규칙)
- `PopoverKeyValue`: `rows[].label`이 `ReactNode`를 받습니다. 화면의 상태 라벨을 설명할 때는 `LabelBadge`를 그대로 넘깁니다
- 예제 · 스토리: 「상품 예약상태 안내」를 `LabelBadge` 이름으로, 구성 절의 Key Value 예시를 상태가 아닌 일반 키-값으로 바꿨습니다. Design 문서에 「상태 라벨을 설명할 때」 Do / Don't를 추가했습니다
- 정본 점검: code-deviates 25 · code-follows-spec 38 · figma-fix 7 · open 18 · resolved 272

## 0.7.4 — 2026-10-08

- 문서: Popover Show Close 절에 Do / Don't를 추가했습니다. 텍스트 버튼이 있는데 닫기를 끄는 조합은 쓰지 않고, 구현은 이 경우에도 닫기를 표시합니다(`closable || title || action`). Figma 세트 설명과 Dev Mode 주석에도 같은 규칙을 적었습니다

## 0.7.3 — 2026-10-08

Popover Figma 세트의 구조 변경(`Show Title`을 Boolean에서 True · False Variant 축으로, `Show Close` 추가)에 맞췄습니다.

- `Popover`: 제목이 없을 때 본문과 닫기(×) 사이를 12에서 8로, 닫기를 첫 줄 가운데에서 위쪽 맞춤으로 바꿨습니다. Figma `Show Title=False` 변형과 같습니다
- 문서: 구성 절과 Show Close 절을 새 구조로 고쳤습니다. 정본 점검: 제목 없는 닫기 · 가이드 예시 26개 인스턴스화 · Popover/List Item 두 줄 넘침을 resolved로
- 정본 점검: resolved 271 · code-follows-spec 38 · code-deviates 25 · figma-fix 7 · open 19

## 0.7.2 — 2026-10-08

Tooltip & Popover의 정본 결정 여덟 가지(닫기 · 화면이 띄우는 Tooltip · 동시 개수 · 폭 · 정렬)를 반영했습니다.

- `Popover`: `closable` 추가(Figma `Show Close`, 기본 true). 제목도 액션도 없는 단문 설명일 때만 false로 닫기 버튼을 끌 수 있습니다. 제목이나 액션이 있으면 false를 넘겨도 닫기 버튼이 남습니다
- `Popover`: `alignTo` 추가. 레이블 뒤에 붙은 트리거일 때 레이블 줄의 ref를 넘기면 카드의 시작 쪽 끝이 레이블 시작에 맞습니다. 트리거가 카드 폭 밖으로 나가면 카드 끝을 트리거 끝에 맞춥니다. 넘기지 않으면 지금처럼 트리거 기준입니다
- `TooltipBadge`: `open` 추가(기본 true). false여도 대상(children)은 다시 마운트되지 않습니다
- `Tooltip`: `onOpenChange`의 두 번째 인자로 닫힌 까닭(`escape` · `outside` · `close`)을 넘깁니다. 타입 `TooltipCloseReason`을 내보냅니다
- 문서: 화면이 띄우는 Tooltip(기능 안내 · 스크롤 진입 안내 · 프로모션)의 규칙과 최소 구현 예제, Show Close 규칙, 레이블 길이에 따른 정렬 여섯 가지 예시를 추가했습니다
- 문서: React 문서의 「화면 끝에서」 예제가 문서 폭에 눌려 카드가 겹치던 것을 고쳤습니다
- 정본 점검: resolved 268 · code-follows-spec 38 · code-deviates 25 · figma-fix 9 · open 19

## 0.7.1 — 2026-10-08

Tooltip & Popover. 3단계(새 컴포넌트)의 첫 컴포넌트입니다.

- 새 컴포넌트 `TooltipBadge`(Figma `Tooltip/Badge`): 버튼 · 가격 옆에 붙이는 브랜드색 알약. `variant`(outlined · filled) · `align`(leading · center · trailing) · `onClose`. 자식을 넘기면 그 요소 위쪽 4px에 붙고 설명(`aria-describedby`)으로 읽힙니다
- 새 컴포넌트 `Popover`(Figma `Popover`): 트리거를 누르면 뜨는 카드. `title` · `content` · `action`, 위치 `position` × `align` 12가지, 폭 180 ~ 320. Esc · 닫기 · 바깥 누르기로 닫히고, 화면 끝에서는 반대쪽 끝에 맞추거나 반대편으로 뒤집힙니다
- 본문 조각 `PopoverList`(Figma `Popover/List Item`) · `PopoverKeyValue`(Figma `Popover/Key Value Row`)
- 새 컴포넌트 `TriggerIcon`(Figma `Tooltip/Trigger Icon`): Popover · Tooltip을 여는 20px 아이콘 버튼(누르는 영역 28). `kind`(question · alert · info)
- `Tooltip`: 열린 뒤 말풍선 크기가 바뀌면(웹 글꼴 교체 등) 위치를 다시 계산합니다
- Tooltip & Popover의 Design · React 문서를 추가하고, 숨겨 두었던 스토리를 사이드바에 올렸습니다. Components Overview 카드가 문서로 연결됩니다

## 0.7.0 — 2026-10-08

겉모습 prop을 `variant`로 통일하고, 0.6.x 동안 남겨 둔 옛 이름을 제거했습니다.

- **Breaking** `Avatar`: `style` → `variant`. 값(`photo` · `filled` · `line`)은 그대로입니다. `<Avatar style="line" />` → `<Avatar variant="line" />`
- **Breaking** `ChipTabs`: `style` → `variant`, 값 `outline` → `outlined`. `<ChipTabs style="outline" />` → `<ChipTabs variant="outlined" />`. CSS 클래스도 `.hds-chiptabs--outlined`입니다
- **Breaking** `LabelBadge`: `variant="line"` → `variant="outlined"`. CSS 클래스도 `.hds-label-badge--outlined`입니다
- **제거** `ButtonBadge` · `ButtonBadgeProps`(0.6.7부터 `MessageBadge` · `MessageBadgeProps`의 별칭)
- **제거** CSS 변수 `--hds-stroke-brand-pressed` · `--hds-stroke-informative-pressed`(→ `--hds-stroke-brand-active` · `--hds-stroke-informative-active`), `--hds-focus-brand`(→ `--hds-focus-default`)

Figma의 겉모습 축이 `Variant`(Filled · Tinted · Outlined)로 통일된 것(2026-10-07)에 맞춘 변경입니다. `style`은 React의 인라인 스타일 속성과 이름이 겹쳤습니다.

## 0.6.22 — 2026-10-08

Figma 이름 표기 맞춤(문서 · 주석). 컴포넌트 코드와 prop 이름 · 값은 바뀌지 않았습니다.

- 전체: 2026-10-07에 Figma에서 바뀐 세트 · 속성 · 축 · 값 이름을 문서 본문, 표, 보드 라벨, 소스 주석에 반영했습니다. 예) `Button/Solid` → `Button/Filled`, `Main Label` → `Label`, `Tab / Chip`의 `Style=Outline` → `Tab/Chip`의 `Variant=Outlined`, `FilterChip` 세트 → `Chip/Filter`, Text Input `Size=48` → `Size=Xlarge`(48), Toast `Variant=Default` → `Status=Normal`
- Selection Controls: Variants 보드와 목록의 축 이름을 Figma대로 `Selection`(선택 여부) · `State`(Default · Disabled)로 고쳤습니다
- Properties & Naming: Boolean 이름(`Show [Element]`), Title Case, `Variant` 축, `Helper Text`, Size 높이 사다리를 2026-10-07 확정 내용으로 고쳤습니다
- Overview: `Text Fields` 카드를 `Text Input`으로 고쳤습니다(Figma 카드도 같이)
- React 문서에서 지금 사실과 다른 문장 3곳을 고쳤습니다: Button/Outlined White · Xlarge와 Checkbox 16 Partial은 Figma에도 있고, Tab/Chip Group 펼친 줄 간격은 Depth와 무관하게 4입니다
- 스토리 이름(사이드바 표기) 8개가 Figma 세트 이름으로 바뀌었습니다. 스토리 id와 URL은 그대로입니다

## 0.6.21 — 2026-10-07

2단계 결정 나머지 12건 반영(문서). 컴포넌트 코드는 바뀌지 않았습니다. Figma가 코드 쪽 값으로 맞춰졌습니다.

- Tabs (Chip): 기본 Size Medium, 넘치면 가로 스크롤, 펼친 줄 간격 4가 Figma에도 반영돼 점검 항목 3건을 닫았습니다. 탭 칩을 「필터」라고 부르던 표현을 「2차 분류 · 서브 카테고리」로 고쳤습니다
- Button: Button/Icon의 Disabled 아이콘 토큰 · 아이콘 색과 굵기, Filter Result 초기화 버튼, Primary With Metrics 아이콘 버튼 48, Panel 값 통일이 Figma에 반영돼 점검 항목 5건을 닫았습니다
- Text Input: Text Fields 가이드에 Show Tooltip 말풍선 규칙이 적혀 점검 항목을 닫았습니다

## 0.6.20 — 2026-10-07

결정 ④ · ⑪ 반영(문서). 컴포넌트 코드는 바뀌지 않았습니다.

- Tabs (Chip): Figma `Tab/Chip Group`이 배경을 갖지 않게 되고 흐림이 마스크로 바뀐 것을 점검 항목에 반영했습니다. 코드는 처음부터 이 방식입니다
- Button: `FloatingAction`의 위치 규칙(화면 아래 가운데, 아래 여백 20)을 Design · React 문서와 예제에 적었습니다. 컴포넌트는 지금처럼 위치를 잡지 않습니다
- Elevation: 선 규칙은 Bottom Fixed에만 적용한다는 범위 결정을 기록했습니다

## 0.6.19 — 2026-10-07

결정 ⑨ · ⑬ · ⑮ 반영.

- **추가** `FilterResult`의 `onRemove(id)` — Figma 칩의 `Icon=On`. 넘기면 칩마다 닫기(×)가 붙고 칩을 눌러 그 조건을 지웁니다. 넘기지 않으면 지금처럼 표시만 합니다. 지운 뒤 포커스는 옆 칩으로 옮겨 갑니다
- **변경** `BottomAction` · `BottomFixed`의 `divider` 기본값이 `false` → `true`. 하단 고정 영역의 위쪽 경계는 1px 선(`stroke/neutral/subtle`)입니다. `BottomFixed`는 선을 Panel 위에 한 번만 그리고 Panel과 Action 사이에는 그리지 않습니다. 선이 필요 없는 자리에서는 `divider={false}`를 넘깁니다
- Text Input의 Tooltip 간격은 물음표 기준으로 확정됐습니다(코드 변경 없음)

## 0.6.18 — 2026-10-07

Text Input의 Show Tooltip 말풍선 구현.

- **추가** `Tooltip` — Figma Tooltip/System. `label` · `size`(small · medium) · `position`(top · bottom · left · right, 자리가 없으면 반대편으로 뒤집힘) · `shortcut` · `closable` · `open` · `defaultOpen` · `onOpenChange`. 올리기(300ms) · 키보드 포커스 · 누르기로 열리고 Esc · 바깥 누르기로 닫힙니다. Popover API로 최상위 레이어에 그립니다. Design · React 문서는 Tooltip & Popover에서 다룹니다(준비 중)
- **변경** `TextInput`의 `tooltip`: 물음표를 올리거나 포커스하거나 누르면 말풍선(Medium, 아래쪽)이 뜹니다. 물음표 버튼의 이름이 `"{label} 입력 도움말: {tooltip}"`에서 `"{label} 입력 도움말"`로 바뀌고 `title`이 빠졌습니다. 문구는 `aria-describedby`로 전달됩니다
- `TextInput`의 문서 전용 `forceState`에 `tooltip`(말풍선을 열어 둠)이 추가됐습니다

## 0.6.17 — 2026-10-07

Bottom Fixed 3종 구현.

- **추가** `BottomAction` — Figma Bottom Fixed/Action. `layout`(6종, 생략하면 넘긴 버튼으로 정함) · `primaryAction` · `secondaryAction` · `iconActions` · `divider`. 버튼 크기는 조합이 정합니다
- **추가** `BottomFixed` — Figma Bottom Fixed/Container. `BottomAction`의 prop + `panel`
- **추가** Panel 부품 `BottomPanelText` · `BottomPanelDateRange`(`nights`를 넘기면 숙박 수 배지) · `BottomPanelChecklist`
- Button 문서의 Bottom Fixed 예시를 실제 컴포넌트로 바꿨습니다

## 0.6.16 — 2026-10-07

Button/Floating_action · FilterResult 구현.

- **추가** `FloatingAction` — Figma Button/Floating_action. `items`(액션 1 ~ 2개, 각각 `icon` · `label` · `onClick` · `ariaLabel`) · `label`(2개일 때 묶음 이름). 위치는 정하지 않습니다
- **추가** `FilterResult` — Figma FilterResult. `chips`(비면 Empty) · `onReset`(넘기면 초기화 버튼) · `emptyMessage` · `label` · `resetLabel`. 칩이 넘치면 가로로 스크롤합니다

## 0.6.15 — 2026-10-06

- **삭제** `ChipTabItem.icon`. Figma `Tab Item / Chip`에서 `Show Icon` · `Icon` 속성을 지운 것에 맞췄습니다. 화살표가 붙는 필터 칩은 `FilterChip kind="dropdown"`을 씁니다. `ChipTabItem`은 이제 `TabItem`과 같은 타입입니다

## 0.6.14 — 2026-10-06

- **Deprecated** `ChipTabItem.icon`(Figma `Show Icon`). 필터 화면을 여는 칩은 여러 개가 동시에 선택되므로 탭이 아닙니다. `FilterChip kind="dropdown"`을 씁니다. 아이콘은 계속 그려지고, Figma 속성이 지워질 때 함께 뺍니다
- ChipTabs 문서: 0.6.13의 용도 설명과 비교 보드를 Do / Don't로 바꿨습니다

## 0.6.13 — 2026-10-06

- ChipTabs 문서: `Show Icon`(항목의 `icon`)의 용도를 "누르면 필터 화면이 열리는 칩"으로 적었습니다. FilterChip `Type=Dropdown`과 나란히 놓은 비교 보드를 넣었습니다. 컴포넌트 동작은 바뀌지 않았습니다

## 0.6.12 — 2026-10-06

- IconButton: `selected`가 켜지면 아이콘 색이 `fg-brand-primary`가 됩니다(이전에는 aria-pressed만). 수치와 테두리는 그대로입니다

## 0.6.11 — 2026-10-06

Button/Icon · Button/Field 구현.

- **추가** `IconButton` — Figma Button/Icon. `icon` · `label`(aria-label) · `count`(아이콘 아래 수치, xlarge 전용) · `size`(xlarge 48 · medium 32) · `selected`(aria-pressed)
- **추가** `FieldButton` — Figma Button/Field. 텍스트 필드 옆 · 안에 붙는 버튼. `tone`(assistive · solid) · `size`(small 28 · large 40 · xlarge 48 · xxlarge 56). 표준 Button과 같고 모서리만 8
- Button: 누름(Pressed) 전환 시간을 150ms → 100ms로 바꿨습니다(`duration-instant`)
- Button: solid · outlined의 폭이 2px 줄어듭니다. 테두리 1px이 좌우 패딩에 더해지던 것을 Figma(테두리가 패딩 안쪽)와 같게 맞췄습니다

## 0.6.10 — 2026-10-02

Tab / Chip 구현.

- **추가** `ChipTabs` · `ChipTabItem` — Figma Tab / Chip · Tab Item / Chip · Tab / Chip Group · Tab / Expand Toggle. `style`(filled · outline) · `size`(small 32 · medium 36 · large 40, 기본 medium) · `color`(black · blue · blue-light · purple · purple-light)
- `style="outline"`은 선택 없이 시작합니다. 제어 모드에서는 `value={null}`이 선택 없음입니다
- `expandable`을 켜면 가로 스크롤 대신 한 줄에 다 들어가지 않을 때 펼침 버튼이 생깁니다(`expanded` · `defaultExpanded` · `onExpandedChange`). 넘침은 컴포넌트가 폭을 재서 판단합니다
- 항목의 `icon`으로 레이블 뒤에 8px 아이콘을 붙일 수 있습니다
- `Tabs`와 달리 항목이 1개여도 행을 그립니다(항목 1개 미렌더 규칙은 Tab / Line 전용)
- Tabs 문서의 Line + Chip 예시가 FilterChip 대신 `ChipTabs`를 씁니다

## 0.6.9 — 2026-10-02

Avatar Filled 배경 토큰.

- Avatar: Filled 배경을 `fg-neutral-disabled-bg` → `bg-neutral-bold`로 바꿨습니다. 두 모드 값이 같아(#bbbbbb · #999999) 화면은 그대로입니다. 실루엣은 흰색 고정을 유지합니다

## 0.6.8 — 2026-10-02

Components 정본 점검 결정 반영 (3) — Toast · Accordion · Avatar.

- Snackbar: 보조 문구(`description`) 색을 `fg-neutral-disabled` → `fg-neutral-contrast`로 바꿨습니다(대비 미달 해소)
- Accordion: 제목이 줄 수 제한 없이 줄바꿈됩니다(이전 2줄 말줄임). 헤더 상하 패딩이 Size별 12 · 16 · 20입니다(이전 고정 12) — 한 줄 제목의 높이 48 · 56 · 64는 그대로이고, 여러 줄일 때 Medium · Large의 여백이 넓어집니다
- Avatar: `editable`이 켜지면 `badge`를 그리지 않습니다

## 0.6.7 — 2026-10-02

포커스 링 전용 토큰.

- **이름 · 값 변경** `--hds-focus-brand` → `--hds-focus-default`. 값이 브랜드 보라(`fg-brand-strong`)에서 `stroke-neutral-strong`(Light #111 · Dark #ddd)으로 바뀝니다. `--hds-focus-brand`는 0.7.0까지 새 토큰의 별칭으로 남습니다(색은 새 값)
- 모든 컴포넌트의 포커스 링이 `--hds-focus-default`를 씁니다(전역 `:focus-visible` · Button · Checkbox · Radio · Toggle · Radio / Segmented · TextInput · Alert Dialog · Bottom Sheet). 값이 같아 화면은 그대로입니다
- 문서 화면(개요 카드 · 아이콘 검색 · 플랫폼 링크)의 포커스 링도 기준(2px · 간격 2px · 중립색)으로 맞췄습니다

## 0.6.6 — 2026-10-02

Label Badge 색 규칙 정리 — Tinted · Line을 semantic 토큰으로.

- 새 색 토큰 4개(accent-purple): `--hds-bg-accent-purple-subtle` · `--hds-fg-accent-purple-primary` · `--hds-fg-accent-purple-contrast` · `--hds-stroke-accent-purple-default`. accent-purple의 쓰임이 "선택 상태 채움 + Label Badge"로 넓어졌습니다
- LabelBadge Tinted: 두 색 모두 `bg-{계열}-subtle` + `fg-{계열}-contrast`입니다. 글자가 한 단계 진해지고 Light · Dark 모두 AA를 통과합니다(보라 5.97 · 5.97, 파랑 4.99 · 7.51). Dark에서 보라 Tinted가 밝은 알약으로 남던 문제가 없어졌습니다
- LabelBadge Line: 보라는 `fg-accent-purple-primary` + `stroke-accent-purple-default`, 파랑 테두리는 `stroke-informative-default`(Light에서 아주 약간 밝아짐)

## 0.6.5 — 2026-10-02

Components 정본 점검 결정 반영 (2) — Button · Badge · Chips · Tabs.

- **포커스 링 통일** — HDS 포커스 표시 기준대로 모든 컴포넌트가 `stroke-neutral-strong` · 2px · 간격 2px입니다. 전역 `:focus-visible`, Button(유형별 색 제거, 어두운 표면용 White 유형만 흰색), Checkbox · Radio · Toggle · Radio / Segmented가 바뀝니다
- **이름 변경** `ButtonBadge` → `MessageBadge`(Figma 세트가 `Badge/Message`로 개명). `ButtonBadge` · `ButtonBadgeProps`는 0.7.0까지 별칭으로 남습니다
- Badge: Notification · Message Alarm 배경 `bg-critical-default`, Message Live 배경 `bg-brand-default`(값 같음)
- ChoiceChip: 새 prop `selectionMode`(`multiple` 기본 · `single`). single은 `<ChipGroup selectionMode="single">` 안에서 라디오로 동작하고 방향키로 고릅니다. 선택 배경은 `bg-brand-subtle`
- SelectChip: 굵기를 모든 상태에서 SemiBold로 고정(선택해도 폭이 변하지 않음), Disabled 배경 `bg-neutral-subtle`
- Toggle thumb는 모든 상태에서 흰색입니다(On도 Dark에서 흰 손잡이)

## 0.6.4 — 2026-10-02

- Toggle Off thumb를 흰색(`--hds-white`)으로 되돌렸습니다. 0.6.3에서 `fg-neutral-contrast`로 바꿨더니 Dark에서 꺼진 토글의 손잡이가 어두워져, Dark에서도 흰 손잡이를 유지하기로 했습니다

## 0.6.3 — 2026-10-02

Components 정본 점검 결정 반영 (1) — Selection Controls.

- 새 색 토큰 `--hds-bg-neutral-bold`(Light #bbb · Dark #999): 켤 수 있지만 꺼져 있는 채움. 값은 `bg-neutral-disabled`와 같습니다
- **화면이 바뀝니다** — Checkbox · Radio 미선택 테두리가 `stroke-neutral-bold`로 진해지고(1.36 → 1.92:1), Toggle Off 트랙이 `bg-neutral-bold`로 진해집니다(1.26 → 1.92:1)
- Checkbox 체크 표시 `fg-neutral-contrast`(Dark 대비 2.57 → 4.99:1), 체크된 박스 배경 `bg-brand-default`(값 같음)
- Radio 비활성 선택 점 `fg-neutral-disabled-strong`(비활성에서도 선택 여부가 보임)
- Checkbox · Radio Item: Disabled면 모든 사이즈에서 Helper와 아이콘도 비활성 색. Radio Item Medium의 라벨–헬퍼 간격 2 → 4
- Toggle Off thumb `fg-neutral-contrast`(On과 같음), Radio / Segmented 선택 테두리 `stroke-neutral-strong`

## 0.6.2 — 2026-10-01

- 새 아이콘 `icAirlogo7c`(제주항공 로고, 색 고정 · 40×28). Figma에서 벡터로 바뀐 것을 반영했습니다. SVG 파일 `icons/icAirlogo7c.svg`
- 아시아나항공(OZ) 로고는 Figma에서 삭제되어 코드에도 넣지 않습니다

## 0.6.1 — 2026-10-01

- 새 간격 토큰 `--hds-spacing-1_5`(6px, 광학 보정용 — 2와 같은 역할). iOS `spacing1_5` · Compose `spacing1_5`

## 0.6.0 — 2026-10-01

Foundation 정본 점검 결정 26건 반영.

- **Deprecated** `--hds-stroke-brand-pressed` · `--hds-stroke-informative-pressed` → `--hds-stroke-brand-active` · `--hds-stroke-informative-active`(Figma 변수 이름 변경, 눌림은 bg · stroke 모두 active). 옛 이름은 0.6.x 동안 새 이름을 가리키는 alias로 남고 0.7.0에서 제거합니다
- **reduced-motion 동작 변경** — 전역 `0.01ms` 규칙을 없애고 Motion 가이드대로 바꿨습니다. Dialog · Alert Dialog · Bottom Sheet · Toast는 이동 없이 페이드만 150ms(`duration/fast` · linear), Segmented 썸 · 토글 썸 · 탭 인디케이터 · 아코디언은 이동을 끕니다. 새 키프레임 `hds-fade-in` · `hds-fade-out`
- 새 텍스트 스타일 `body/md-long`(행간 160%, 약관 · 상품 상세 장문용): `.hds-text-body-md-long`, `--hds-body-md-line-height-long`
- `--hds-font-base`에 `'Malgun Gothic'` 추가(가이드 폴백 스택과 같아짐)
- 네이티브 토큰: iOS 텍스트 스타일이 Mobile + 1pt(가이드의 iOS +1 규칙). Android · XML은 그대로
- 문서: Emphasis 정본 표, Elevation 레벨 ↔ 그림자 · 표면 매핑, Grid 이름 대응표 · gutter-lg 용도, Motion emphasized 허용 행, UX Writing 승인 규칙 19개 · Toast/Snackbar 행, 표의 한 항목 셀은 글머리 없이 표시

## 0.5.1 — 2026-09-30

- `icChevronLeftCircleFilled`: 원이 흰색이라 보이지 않던 것을 고침(Figma Foundation 수정 반영)
- `icOFilled`: 안쪽 원이 검정이던 것을 흰 심볼(`--hds-icon-knockout`)로 고침

## 0.5.0 — 2026-09-30

Foundation 누락분 추가 · 토큰 원본 교체.

- 토큰 원본을 Figma HDS-Foundation의 **변수 610개 · 스타일 전체 스냅숏**(`tokens/raw/figma.json`)으로 교체했습니다. 값을 코드에 손으로 적지 않습니다. 갱신은 `tokens/figma-export.js` → `tokens/merge-figma-export.mjs`
  - 새 토큰: `--hds-overlay-adaptive-tint`(Light 검정 4% · Dark 흰색 4%), `--hds-color-static-white-alpha-4`, `--hds-content-width-mobile-sm·md·lg`
  - `--hds-{scale}-font` · `--hds-{scale}-weight-regular·emphasized·strong`(typography-scale 변수), `.hds-text-*`가 이 변수를 씀
  - 기존 토큰 값은 바뀌지 않았습니다(layout 값이 number 토큰 alias로 바뀐 것뿐)
- **Gradient** — `--hds-gradient-*` 15개(scrim · fade · 브랜드), 테마를 따라가는 `--hds-gradient-fade-{top·right·bottom·left}`, 가장자리를 지우는 `.hds-mask-{방향}` + `.hds-mask-{xxs…xl}`
- **Ratio** — `--hds-ratio-*` · `.hds-ratio-*` 17종(Figma `Ratio` 컴포넌트)
- **Grid & Layout** — `.hds-container` · `.hds-grid` · `.hds-col-1…12` · `.hds-col-full`, `breakpoints` · `platformForWidth()`
- 스토리북 Foundation 문서 4개 추가: Gradient · Grid & Layout · UX Writing · Properties & Naming

## 0.4.0 — 2026-09-30

Foundation 아이콘 추가.

- `Icon` 컴포넌트와 Foundation 아이콘 423개(`icCloseBold`, `icChevronDownBold` …). 아이콘마다 따로 export 되어 쓰는 것만 번들에 들어갑니다.
  - `size`는 높이(px, 기본 24), `label`을 주면 `role="img"`, 없으면 `aria-hidden`
  - 단색 아이콘은 `currentColor`, Filled의 흰 심볼은 `--hds-icon-knockout`(기본 `fg/neutral/contrast`)으로 칠해 Dark 모드에서도 대비 유지. Color 아이콘은 그려진 색 그대로
- SVG 파일 — `@aliceblue567/hds-react/icons/<이름>.svg` (iOS · Android · 기타 도구용)
- 컴포넌트 안의 아이콘을 Foundation 아이콘으로 교체: Accordion · Button(Txt 화살표) · Dialog · BottomSheet · Chips · Selection Controls · TextInput · Toast · Snackbar · Avatar · Badge. 모양이 Figma 인스턴스와 같아졌습니다(선 굵기 · 모서리)
- `Toast` 상태 아이콘은 Filled + 상태 색 토큰(`fg/positive · warning · critical/primary`)
- 스토리북 Foundation › Iconography 문서 (원칙 · 크기 · 색 정책 · 컴포넌트별 아이콘 · 전체 갤러리)

## 0.3.0 — 2026-09-30

코드 ↔ 가이드 불일치 수정.

- **Breaking** `Button` `variant="text"`의 `arrow` 기본값이 켜짐으로 바뀌었습니다(Figma 기본 On). 화살표가 필요 없는 자리에서는 `arrow={false}`를 넘깁니다.
- `Button` text: 글자 높이와 관계없이 터치 영역 44px 확보
- `Dialog` · `BottomSheet`: 열려 있는 동안 뒤 페이지 스크롤 잠금. Dialog는 안에서 누르고 배경에서 뗀 경우 닫히지 않음
- `BottomSheet`: 핸들 버튼 터치 영역 48×32
- `Toast` · `Snackbar`: ToastRegion이 처음부터 둔 라이브 영역으로 알림을 읽음(Negative는 즉시). 소멸 모션 150ms 추가(모션 줄이기 설정이면 생략). Snackbar 닫기 버튼 이름 "닫기"
- `Avatar`: `src`가 바뀌면 이미지 실패 상태를 다시 확인
- `SegmentedControl`: 항목별 `disabled`, 나머지 `<div>` 속성 전달, 4개 초과 · 없는 value일 때 개발 모드 경고
- `Tabs`: 나머지 `<div>` 속성 전달, 선택값이 없을 때도 키보드로 진입 가능, 탭 이동 시 페이지 세로 스크롤을 건드리지 않음, 긴 라벨 말줄임
- `TextInput`: `readOnly` 모양(배경 · 지우기 버튼 숨김), 외부 `aria-describedby`를 도움말과 합침

## 0.2.0 — 2026-09-30

- iOS · Android 토큰 추가 — `@aliceblue567/hds-react/tokens/ios/HDSTokens.swift`, `tokens/android/compose/HdsTokens.kt`, `tokens/android/res/…/hds_colors.xml · hds_dimens.xml`
  - semantic 색 123개(Light · Dark), 간격 · 모서리 · 아이콘 · 테두리 · 레이아웃(휴대폰 값), 글자 17종(Mobile 크기), 모션
  - 웹과 같은 Figma 변수에서 `npm run tokens`로 함께 생성
- 스토리북 Foundation › iOS & Android 문서 (이름 대응표, 사용 예, 파일 받기)

## 0.1.0 — 2026-09-30

첫 배포 (GitHub Packages 비공개).

- 컴포넌트 13종: Accordion · Avatar · Badge · BottomSheet · Button · Chips · Dialog(AlertDialog) · Divider · SegmentedControl · SelectionControls · Tabs · TextInput · Toast(Snackbar)
- `@aliceblue567/hds-react/styles` — 디자인 토큰(CSS 변수) + 기본 스타일 + 컴포넌트 CSS 한 파일
- `@aliceblue567/hds-react/tokens.json` — 토큰 원본 값 (네이티브 · 다른 도구용)
- 테마 · 플랫폼은 `<html data-theme="light|dark" data-platform="mobile|tablet|desktop">`
- Dark `bg/surface/primary`는 `#000000` (2026-09-29 Foundation 변경 반영)
