# HDS Storybook · @aliceblue567/hds-react

Figma HDS(Hanatour Design System)를 코드로 다시 만든 개인 포트폴리오 작업입니다. 문서: https://hds-storybook.vercel.app

## 패키지로 쓰기 (GitHub Packages · 비공개)

이 저장소에 접근 권한이 있는 계정만 설치할 수 있습니다.

1. GitHub → Settings → Developer settings → Personal access tokens → **Tokens (classic)** → `read:packages` 권한으로 토큰 생성
2. 쓸 프로젝트 폴더에 `.npmrc`:

```
@aliceblue567:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_PACKAGES_TOKEN}
```

3. 토큰은 파일에 적지 말고 환경 변수로: `~/.zshrc`에 `export GITHUB_PACKAGES_TOKEN=ghp_…`
4. 설치 · 사용

```bash
npm install @aliceblue567/hds-react
```

```tsx
import '@aliceblue567/hds-react/styles';            // 앱 진입점에서 한 번
import { Button, FilterChip } from '@aliceblue567/hds-react';

<Button label="예약하기" />
```

- React 18 이상. 글꼴 Pretendard는 포함하지 않습니다 — 앱에서 불러옵니다.
- 테마 · 플랫폼: `<html data-theme="light|dark" data-platform="mobile|tablet|desktop">`

변경 내용: [CHANGELOG.md](./CHANGELOG.md)

## AI 도구에서 쓰기 (AI Kit)

Claude Code · Cursor · v0 같은 AI 코딩 도구가 HDS 컴포넌트만으로 화면을 조립하게 하려면, 패키지의 `ai/` 산출물을 쓰는 저장소 루트에 둡니다.

```bash
cp node_modules/@aliceblue567/hds-react/ai/AGENTS.md ./AGENTS.md
mkdir -p ai && cp node_modules/@aliceblue567/hds-react/ai/hds-components.md ai/
```

- `ai/AGENTS.md` — 규칙 + 컴포넌트 인덱스(에이전트가 항상 읽는 짧은 파일)
- `ai/hds-components.md` — props 전체(필요한 절만 읽음)
- `ai/hds-catalog.json` · `ai/hds-figma-map.json` — 기계용. Figma 속성 → 코드 prop 대응은 JSDoc의 ``Figma `속성명` `` 표기에서 자동으로 나옵니다
- 생성: `npm run ai-kit`(`build:lib`에 포함). 손으로 고치지 않습니다 — 소스 JSDoc을 고칩니다

## 개발


```bash
npm install
npm run storybook        # http://localhost:6006
npm run build-storybook  # storybook-static/
npm run build:lib        # dist/ (npm 패키지)
```

- `tokens/raw/figma.json` — Figma HDS-Foundation의 변수 610개 · 스타일(텍스트 · 이펙트 · 그라디언트 · 그리드) 전체 스냅숏. 갱신: `tokens/figma-export.js`(Figma에서 실행) → `node tokens/merge-figma-export.mjs`
- `tokens/raw/icons.json` — Foundation 아이콘 424개 SVG
- `tokens/build.mjs` — figma.json → `src/styles/tokens.css`·`tokens.json` 생성. 깨진 alias가 있으면 실패. 값을 손으로 적지 않음
- `src/foundation/` — Foundation 문서 스토리
- 툴바 Theme(Light/Dark) · Platform(Mobile/Tablet/Desktop) = Figma 변수 모드

`tokens.css`는 생성물이라 커밋하지 않습니다.

## 배포

1. `CHANGELOG.md`에 새 버전 항목을 쓰고, `package.json`의 `version`을 올립니다.
2. main에 푸시하면 GitHub Actions(`.github/workflows/publish.yml`)가 새 버전을 빌드해 GitHub Packages(비공개)에 올리고 `v0.1.1` 태그를 남깁니다. 이미 올라간 버전이면 건너뜁니다. 토큰 설정은 필요 없습니다.
4. 공개 npm으로 옮기는 방법은 workflow 파일 머리 주석에 있습니다. 회사 확인 전에는 옮기지 않습니다.
